<?php $__env->startSection('css'); ?>
    <style>
        .card-footer p {
            display: none;
        }
    </style>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/auth/login.blade.php ENDPATH**/ ?>