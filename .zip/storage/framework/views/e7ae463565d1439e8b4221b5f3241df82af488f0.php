<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Coupons</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Content</th>
            <th scope="col">Control</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td><?php echo e($policy['id']); ?></td>
            <td><?php echo e($policy['content']); ?></td>
            <td>
                <div class="col-6">
                    <a href="<?php echo e(url('policy/edit/' . $policy['id'])); ?>"> <button class="btn btn-bg btn-primary w-100">Edit</button></a>
                </div>
            </td>
        </tr>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/Policy/index.blade.php ENDPATH**/ ?>