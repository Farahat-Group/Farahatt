<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Services</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Title</th>
            <th scope="col">Category</th>
            <th scope="col">Price</th>
            <th scope="col">Sale</th>
            <th scope="col">Service Code</th>
            <th scope="col">Control</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($service['id']); ?></th>
                <td><?php echo e($service['title']); ?></td>
                <td><?php echo e($service->category->title); ?></td>
                <td><?php echo e($service['price']); ?>$</td>
                <td><?php echo e($service['sale']); ?>%</td>
                <td><?php echo e($service['service_code']); ?></td>
                <td width="200px">
                    <div class="row w-100">
                        <div class="col-6">
                            <a href="<?php echo e(url('services/edit/' . $service['id'])); ?>"> <button class="btn btn-bg btn-primary w-100">Edit</button></a>
                        </div>
                        <div class="col-6">
                            <form action="<?php echo e(route('services.destroy', $service['id'])); ?>" method='POST'>
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete" class="btn btn-bg btn-danger w-100">

                            </form>
                        </div>

                    </div>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
   <a href="<?php echo e(url('services/create')); ?>"> <button class="btn btn-bg btn-success">Add Service</button></a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/services/index.blade.php ENDPATH**/ ?>