<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add Users</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <h1 class="text-center mb-5 mt-5">Add Member</h1>
        <div class="container">
            <form action="<?php echo e(url('admin/users')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row mx-5 mb-4">
                    <div class="col-2">
                        <label for="username" class="col-form-label">Username</label>
                    </div>
                    <div class="col-10">
                        <input type="text" name="name" id="username" required="required" class="form-control" autocomplete="off" placeholder="Username" value="<?php echo e(old('name')); ?>">
                    </div>
                </div>
                <div class="row mx-5 mb-4">
                    <div class="col-2">
                        <label for="inputPassword" class="col-form-label">Password</label>
                    </div>
                    <div class="col-10">
                        <input type="password" name="password" id="inputPassword" class="form-control text" autocomplete="new-password" placeholder="Password">

                    </div>
                </div>

                <div class="row mx-5 mb-4">
                    <div class="col-2">
                        <label for="email" class="col-form-label">Email</label>
                    </div>
                    <div class="col-10">
                        <input type="email" name="email" id="email" required="required" class="form-control text" autocomplete="off" placeholder="Email">
                    </div>
                </div>

                <div class="row justify-content-center">
                    <div class="col-5">
                        <button type="submit" class="btn btn-primary btn-lg  mx-5" style="width:100%">Add</button>
                    </div>
                </div>
            </form>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/customers/create.blade.php ENDPATH**/ ?>