<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Policy</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center mb-5 mt-5">Edit Policy</h1>
    <div class="container">
        <form action="<?php echo e(url('policy')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row mx-5 mb-4">
                <div class="col-2">
                    <label for="cat" class="col-form-label">Content</label>
                </div>
                <div class="col-10">
                    <textarea cols="20" rows="14" type="text" name="content" id="username" required="required" class="form-control" autocomplete="off" placeholder="Policy Content"></textarea>
                </div>
            </div>


            <div class="row justify-content-center">
                <div class="col-5">
                    <button type="submit" class="btn btn-primary btn-lg  mx-5" style="width:100%">Edit Policy</button>
                </div>
            </div>

        </form><br>
        <?php $__empty_1 = true; $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="alert alert-danger"><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/Policy/edit.blade.php ENDPATH**/ ?>