<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Customers</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Control</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <th scope="row"><?php echo e($customer['id']); ?></th>
            <td><?php echo e($customer['name']); ?></td>
            <td><?php echo e($customer['email']); ?></td>
            <td>
            <form action="<?php echo e(route('customer.delete', $customer['id'])); ?>" method='POST'>
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <input type="submit" value="Delete" class="btn btn-bg btn-danger">

            </form>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No Customers Yet
        <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/customers/index.blade.php ENDPATH**/ ?>