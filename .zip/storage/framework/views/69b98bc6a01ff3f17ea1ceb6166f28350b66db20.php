<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Order Details</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center mb-5 mt-5">Order Details</h1>
    <div class="container">
        <div class="d-inline-block mr-5">
            <h3>Order id</h3> <span style="color: #000;font-weight: bold;font-size: 20px"><?php echo e($order['id']); ?></span>
        </div>
        <div class="d-inline-block mr-5">
            <h3>Order Amount</h3> <span style="color: #000;font-weight: bold;font-size: 20px"><?php echo e($order['cash'] - $order['sale']); ?></span>
        </div>
        <div class="d-inline-block mr-5">
            <h3>Order Sale</h3> <span style="color: #000;font-weight: bold;font-size: 20px"><?php echo e($order['sale']); ?></span>
        </div>

        <div class="d-inline-block mr-5">
            <h3>Payment Method</h3> <span style="color: #000;font-weight: bold;font-size: 20px">
                 <?php switch($order->payment_method):
                    case (0): ?>
                    Vodafone Cash : <span style="color: #F00"> <?php echo e($order->payment_code); ?></span>
                    <?php break; ?>

                    <?php case (1): ?>
                    Cash On Delivery
                    <?php break; ?>
                <?php endswitch; ?>
            </span>
        </div>
        <br><br><br><br>


        <div class="row">
            <?php if($order['status'] == 0): ?>
            <div class="col-6">
                    <a href="<?php echo e(url('orders/accept/' . $order['id'])); ?>"><button class="btn btn-lg btn-success">Accept Order</button></a>
            </div>
            <?php endif; ?>
                <div class="col-3">
                    <form action="<?php echo e(route('orders.destroy', $order['id'])); ?>" method='POST'>
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="Delete" class="btn btn-bg btn-danger w-100">

                    </form>
                </div>
        </div>

        <h2 class="mt-5 ml-3">Order Products</h2>
        <br><br><br>

        <div class="row">
                <?php $__currentLoopData = $order->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mr-3" style="width: 18rem;">
                    <img class="card-img-top" src="<?php echo e(url('images/services/') . $service->service['images']); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($service->service->title); ?></h5>
                        <p class="card-text"><?php echo e($service->service->description); ?></p>
                        <p class="card-text">Price: <?php echo e($service->service->price); ?></p>
                        <p class="card-text">PriceAfterSale: <?php echo e($service->service->priceAfterSale); ?></p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>



    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/orders/show.blade.php ENDPATH**/ ?>