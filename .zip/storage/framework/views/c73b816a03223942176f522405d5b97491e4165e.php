<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add Notification</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center mb-5 mt-5">Add Notification</h1>
    <div class="container">
        <form action="<?php echo e(url('notifications')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row mx-5 mb-4">
                <div class="col-2">
                    <label for="cat" class="col-form-label">Customer</label>
                </div>
                <div class="col-10">
                    <select name="customer_id" id="cat" class="form-control">
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service['id']); ?>"><?php echo e($service['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>


            <div class="row mx-5 mb-4">
                <div class="col-2">
                    <label for="username" class="col-form-label">Message</label>
                </div>
                <div class="col-10">
                    <input type="text" name="message" id="username" required="required" class="form-control" autocomplete="off" placeholder="Message">
                </div>
            </div>

            <div class="row mx-5 mb-4">
                <div class="col-2">
                    <label for="username" class="col-form-label">Price</label>
                </div>
                <div class="col-10">
                    <input type="number" name="price" id="username" class="form-control" autocomplete="off" placeholder="Price">
                </div>
            </div>






            <div class="row justify-content-center">
                <div class="col-5">
                    <button type="submit" class="btn btn-primary btn-lg  mx-5" style="width:100%">Send Notification</button>
                </div>
            </div>

        </form><br>
        <?php $__empty_1 = true; $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="alert alert-danger"><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/notifications/create.blade.php ENDPATH**/ ?>