<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Ads</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">title</th>
            <th scope="col">description</th>
            <th scope="col">Image</th>

            <th scope="col">Control</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($board['id']); ?></th>
                <td><?php echo e($board['title']); ?></td>
                <td><?php echo e($board['description']); ?></td>
                <td>
                   <img width="150" height="100px" src="<?php echo e(url('images/boards/' .$board['image'])); ?>" alt="photo">
                </td>
                <td width="200px">
                    <div class="row w-100">
                        <div class="col-6">
                            <a href="<?php echo e(url('board/edit/' . $board['id'])); ?>"> <button class="btn btn-bg btn-primary w-100">Edit</button></a>
                        </div>
                        <div class="col-6">
                            <form action="<?php echo e(route('boards.delete', $board['id'])); ?>" method='POST'>
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete" class="btn btn-bg btn-danger">

                            </form>
                        </div>

                    </div>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/boarding/index.blade.php ENDPATH**/ ?>