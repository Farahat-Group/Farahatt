<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Notifications</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">order_id</th>
            <th scope="col">Customer</th>
            <th scope="col">Cash</th>
            <th scope="col">Sale</th>
            <th scope="col">Price After Sale</th>
            <th scope="col">Status</th>
            <th scope="col">Control</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($order['id']); ?></th>
                <td><?php echo e($order->customer->name); ?></td>
                <td><?php echo e($order->cash); ?></td>
                <td><?php echo e($order['sale']); ?>$</td>
                <td><?php echo e($order->cash - $order->sale); ?>$</td>
                <td>
                    <?php switch($order->status):
                    case (0): ?>
                    On Hold
                    <?php break; ?>

                    <?php case (1): ?>
                    Processing
                    <?php break; ?>

                    <?php case (2): ?>
                    Completed
                    <?php break; ?>

                    <?php default: ?>
                    Rejected
                    <?php endswitch; ?>
                </td>
                <td width="200px">
                    <div class="row w-100">
                        <div class="col-6">
                            <form action="<?php echo e(route('orders.destroy', $order['id'])); ?>" method='POST'>
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Delete" class="btn btn-bg btn-danger w-100">

                            </form>
                        </div>

                        <div class="col-6">
                            <a href="<?php echo e(url('orders/' . $order['id'])); ?>"> <button class="btn btn-bg btn-primary w-100">Details</button></a>
                        </div>

                    </div>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Farahat\resources\views/orders/index.blade.php ENDPATH**/ ?>