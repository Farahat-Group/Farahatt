<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ExtraServiceController extends Controller
{
    //
}
