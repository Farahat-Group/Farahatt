@extends('adminlte::auth.login')
@section('css')
    <style>
        .card-footer p {
            display: none;
        }
    </style>
    @endsection
